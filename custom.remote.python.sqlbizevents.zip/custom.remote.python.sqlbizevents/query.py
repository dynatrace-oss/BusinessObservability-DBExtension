SSO_AUTH="https://sso.dynatrace.com/sso/oauth2/token"
