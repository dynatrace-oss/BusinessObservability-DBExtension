import json
import logging
from constant import *
import requests, pymysql
from decimal import Decimal
from datetime import datetime, timedelta
from ruxit.api.base_plugin import RemoteBasePlugin

logger = logging.getLogger(__name__)

# *******************************************************************************
#           Class definition for the extension 
# *******************************************************************************
class BusinessObservabilityDatabaseExtension(RemoteBasePlugin):

    def initialize(self, **kwargs):
        logger.info("Config: %s", self.config)
        self.queryiteration = 0
        self.sqlip = self.config.get("sqlip", "localhost")
        self.sqlusername = self.config.get("username", "db_user")
        self.sqlpassword = self.config.get("sqlpassword", "password")
        self.sqldb = self.config.get("sqldb", "test_db")
        self.endpointtopushbizevents = self.config.get("endpointtopushbizevents", "https://abc.live.dynatrace.com/api/v2/bizevents/ingest/")
        self.clientId = self.config.get("clientid", "token")
        self.clientsecret = self.config.get("clientsecret", "token")
        self.query1 = self.config.get("query1", "select * from mytable")
        self.query2 = self.config.get("query2", "select col1, col2 from mytable")
        self.query3 = self.config.get("query3", "select col1, col2, col3 from my table groupby (col1)")
        self.queryname1 = self.config.get("queryname1", "query1")
        self.queryname2 = self.config.get("queryname2", "query2")
        self.queryname3 = self.config.get("queryname3", "query3")
        self.interval1 = int(self.config.get("interval1", "1"))
        self.interval2 = int(self.config.get("interval2", "30"))
        self.interval3 = int(self.config.get("interval3", "60"))

        #Connecting to the database in the backend
        self.conn = pymysql.connect(host=self.sqlip, user=self.sqlusername, password=self.sqlpassword,
                       db=self.sqldb,charset='utf8mb4', cursorclass=pymysql.cursors.DictCursor)
        self.cursor = self.conn.cursor()
 

    def query(self, **kwargs):
       try:
         logger.info("Completed execution of query")  
         #Create topology
         group_name = "MySQL DB Fetch" 
         endpoint=self.activation.endpoint_name.strip()
         g1 = self.topology_builder.create_group(group_name, group_name)

         topology_device = g1.create_element(group_name + " - " + endpoint, group_name + " - " + endpoint)
         topology_device.report_property("Endpoint Name", endpoint)
         topology_device.report_property("Plugin version", kwargs["json_config"]["version"])
         entityID = f"CUSTOM_DEVICE-{topology_device.id:X}"
        
         print("Here are the intervals")
         print(self.queryiteration)
         print(self.interval1)
         print(self.interval2)
         print(self.interval3)

         if self.queryiteration % ROTATE_BEARER_TOKEN  == 0:
           self.bearertoken=""
           self.bearertoken = self.rotateToken(self.clientsecret, self.clientId)
           print(self.bearertoken)

         if self.queryiteration % self.interval1 == 0:
           print("Executing query1" , self.interval1)
           self.cursor.execute(self.query1)
           result = self.cursor.fetchall()
           self.conn.commit()

           self.addkeyValue(result, self.queryname1, entityID)
           print("Executed query2: ", self.cursor._last_executed)
           print("Number of records returned", str(len(result)))

         if self.queryiteration % self.interval2 == 0:
           print("Executing query2" , self.interval2)
           self.cursor.execute(self.query2)
           result = self.cursor.fetchall()
           self.conn.commit()
           self.addkeyValue(result, self.queryname2, entityID)
           print("Executed query2: ", self.cursor._last_executed)
           print("Number of records returned", str(len(result)))

         if self.queryiteration % self.interval3 == 0:
           print("Executing query3" , self.interval3)
           self.cursor.execute(self.query3)
           result = self.cursor.fetchall()
           self.conn.commit()
           self.addkeyValue(result, self.queryname3, entityID)
           print("row size before going in loop", str(len(result)))

         self.queryiteration = self.queryiteration + 1

       except Exception as e:
         logger.exception("Exception encountered in query", str(e))

       finally:
         logger.info("Completed execution of query")  

   # *******************************************************************************
   #           Function for configuration API for publish tenant
   # *******************************************************************************
    def close(self, **kwargs):
       print("will close the connection") 
       self.cursor.close()
       self.conn.close()

    # *******************************************************************************
    #           Function for adding query details to the function 
    # *******************************************************************************
    def addkeyValue(self, result, queryname, entityID): 
      try:  
        logger.info("In addkeyValue")

        modified_result = []
        modified_result_list = []
        for row in result:
            new_row = row.copy()
            new_row["status"]="INFO"
            new_row["event.provider"]=queryname
            new_row["event.type"]="Data Source"

            for key, value in new_row.items():
                if isinstance(value, datetime):
                    new_row[key] = value.strftime('%Y-%m-%d %H:%M:%S')
                if isinstance(value, Decimal):
                    new_row[key] = float(value)
            modified_result.append(new_row)

            if len(modified_result) >= 400:
                modified_result_list.append(modified_result)

      except Exception as e:
         logger.exception("Exception encountered in addkeyValue", str(e))

      finally:  
        logger.info("Execution completed addkeyValue")
        modified_result_list.append(modified_result)
        self.pushdata(modified_result_list)
    
    # *******************************************************************************
    #           Function to rotate Bearer Token 
    # *******************************************************************************
    def rotateToken(self, clientsecret, clientid):
      try:
        logger.info("In rotateToken")

        headers = {
           'Content-Type': 'application/x-www-form-urlencoded',
        }
        data = 'grant_type=client_credentials&client_id={}&client_secret={}&scope:storage:events:read, storage:events:write, storage:logs:read,storage:metrics:read'.format(clientid, clientsecret)
        response = requests.post("https://sso.dynatrace.com/sso/oauth2/token", headers=headers, data=data, verify=False)

        print(response)
        if response.status_code >= 400 and response.status_code <= 600:
            logger.info("Rotating Token failed", str(response.status_code))

        token_data = response.json()

      except Exception as e:
         logger.exception("Exception encountered in rotateToken", str(e))

      finally:
        logger.info("Execution completed rotateToken")
        return token_data["access_token"]
          
    # *******************************************************************************
    #           Function for configuration API for publish tenant
    # *******************************************************************************
    def pushdata(self, payloadList): 
      try:  
        logger.info("In pushdata")

        post_param = {'Accept':'application/json','Content-Type':'application/json; charset=utf-8', 'Authorization':'Bearer {}'.format(self.bearertoken)}
        print(len(payloadList))
        print(f"Using the bearertoken: {self.bearertoken}")

        for payload in payloadList:
          populate_data = requests.post(self.endpointtopushbizevents, data=json.dumps(payload), headers=post_param, verify=False)
          print(populate_data.status_code)

      except Exception as e:
         logger.exception("Exception encountered in pushdata", str(e))

      finally:  
        logger.info("Execution completed pushdata")
